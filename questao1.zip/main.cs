/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    Console.WriteLine("Digite a caracteristica");
    string entrada1 =
    Console.WriteLine().tolower();
    
    Console.WriteLine("Digite a segunda caracteristica");
    string entrada2 =
    Console.ReadLine().tolower();
    
    Console.WriteLine("Digite a terceira caracteristica");
    string entrada3 = 
    Console.ReadLine().tolower();
    
    string animal = "";
    
    if (entrada1 = "vertebrado")
    {
        if (entrada2) = "ave")
        {
            if (entrada3) = "carnivoro")
            animal= "Aguia";
            else if (entrada3 = "onivoro")
            animal= "pomba";
        }
        else if (entrada2) = "mamifero")
        {
            if(entrada3) = ("onivoro")
            animal = "homem";
            else if (entrada3) = "herbivoro"
            animal = "lagarta";
        }
        else if (entrada2) = ("aneolideo") 
        {
            if (entrada3) = ("hematofogo")
            animal = "sanguessuga";
            
        else if (entrada3) = ("onivoro")
        animal = "minhoca";
        }
    }
    
    Console,WriteLine(animal.ToUpper());
  }
}

        }
        }
    }
  }
}