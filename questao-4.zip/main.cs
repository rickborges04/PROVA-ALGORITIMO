/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    Console.WriteLine("Digite a primeira data (formato: dd/mm/yyyy)");
    Datatime data1;
    while (!
    Datatime.tryParse(Console.readline), out data1))
    {
        Console.WriteLine("data invalida. Digite novamente no formato dd/mm/yyyy:");
        Console.WriteLine("Digite a segunda data (formato: dd/mm/yyyy");
        datatime data2;
        while (!
        Datatime.tryParse(Condole.readline(), out data2));
    }
    int diferencadias = 
    math.Abs((data2 - data1).Days);
    Console.WriteLine($"a difeerença entre as datas é de {diferencadias} dia(s).");
  }
}

}