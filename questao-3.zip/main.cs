/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
    Console.WriteLine("Digite a idade em dias");
    int totaldias = 
    int.Parse (Console.ReadLine());
    int anos = totaldias / 365;
    int restante = totaldias % 365;
    int meses = restante / 30;
    int dias = restante % 30;
    
    Console.WriteLine($"{anos} ano(s)");
    Console.WriteLine($"{meses} mes(es)");
    Console.WriteLine($"{dias}  dia(s)");
  }
}

  }
}